select prd.codigo_produto
     , prd.descricao_produto 
  from produtos prd
 order by prd.descricao_produto 