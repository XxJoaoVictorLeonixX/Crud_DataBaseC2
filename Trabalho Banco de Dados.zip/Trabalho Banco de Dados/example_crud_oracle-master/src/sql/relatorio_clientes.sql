select c.cpf
     , c.nome 
  from clientes c
 order by c.nome