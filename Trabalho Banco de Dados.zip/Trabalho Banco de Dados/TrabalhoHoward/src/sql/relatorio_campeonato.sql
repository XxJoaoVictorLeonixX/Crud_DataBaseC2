select c.campeonato
     , c.id_campeonato
     , c.nome
     , c.premiacao
  from campeonato c
  order by c.id_campeonato