select j.cpf
     , j.nome
	 , j.id_time
	 , j.numero
	 , j.data_nascimento
	 , j.posicao
  from jogadores j
 order by j.nome, j.cpf