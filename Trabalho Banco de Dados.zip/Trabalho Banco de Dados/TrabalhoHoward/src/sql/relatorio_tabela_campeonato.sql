select t.id_time
     , c.id_campeonato
     , SUM(p.vitorias) as total_vitorias
     , SUM(p.derrotas) as total_derrotas
     , SUM(p.empates) as total_empates
     , SUM(p.gol_feito) as total_gol_feito
     , SUM(p.gol_sofrido) as total_gol_sofrido
  from tabela_campeonato p
  inner join times t on p.id_time = t.id_time
  inner join campeonatos c on p.id_campeonato = c.id_campeonato
  group by t.id_time, c.id_campeonato
  order by t.id_time;