select t.times
       , t.id_time
       , t.nome
  from times t
 order by t.id_time