select e.id_jogo
       , e.estadio
       , e.time_mandante
	   , e.time_visitante
	   , e.gol_mandante
	   , e.gol_visitante
	   , c.id_campeonato
  from jogos e
 order by e.id_jogo