from conexion.oracle_queries import OracleQueries

class Relatorio:
    def __init__(self):
        # Abre o arquivo com a consulta e associa a um atributo da classe
        with open("sql/relatorio_times.sql") as f:
            self.query_relatorio_times = f.read()

        # Abre o arquivo com a consulta e associa a um atributo da classe
        with open("sql/relatorio_jogadores.sql") as f:
            self.query_relatorio_jogadores = f.read()

        # Abre o arquivo com a consulta e associa a um atributo da classe
        with open("sql/relatorio_campeonato.sql") as f:
            self.query_relatorio_campeonato = f.read()

        # Abre o arquivo com a consulta e associa a um atributo da classe
        with open("sql/relatorio_tabela_campeonato.sql") as f:
            self.query_relatorio_tabela_campeonato = f.read()

        # Abre o arquivo com a consulta e associa a um atributo da classe
        with open("sql/relatorio_jogos.sql") as f:
            self.query_relatorio_jogos = f.read()

    def get_relatorio_times(self):
        # Cria uma nova conexão com o banco que permite alteração
        oracle = OracleQueries()
        oracle.connect()
        # Recupera os dados transformando em um DataFrame
        print(oracle.sqlToDataFrame(self.query_relatorio_times))
        input("Pressione Enter para Sair do Relatório de Times")

    def get_relatorio_jogadores(self):
        # Cria uma nova conexão com o banco que permite alteração
        oracle = OracleQueries()
        oracle.connect()
        # Recupera os dados transformando em um DataFrame
        print(oracle.sqlToDataFrame(self.query_relatorio_jogadores))
        input("Pressione Enter para Sair do Relatório de Jogadores")

    def get_relatorio_campeonato(self):
        # Cria uma nova conexão com o banco que permite alteração
        oracle = OracleQueries()
        oracle.connect()
        # Recupera os dados transformando em um DataFrame
        print(oracle.sqlToDataFrame(self.query_relatorio_campeonato))
        input("Pressione Enter para Sair do Relatório de Campeonato")

    def get_relatorio_tabela_campeonato(self):
        # Cria uma nova conexão com o banco que permite alteração
        oracle = OracleQueries()
        oracle.connect()
        # Recupera os dados transformando em um DataFrame
        print(oracle.sqlToDataFrame(self.query_relatorio_tabela_campeonato))
        input("Pressione Enter para Sair do Relatório de Tabela Do Campeonato")

    def get_relatorio_jogos(self):
        # Cria uma nova conexão com o banco que permite alteração
        oracle = OracleQueries()
        oracle.connect()
        # Recupera os dados transformando em um DataFrame
        print(oracle.sqlToDataFrame(self.query_relatorio_jogos))
        input("Pressione Enter para Sair do Relatório de Jogos")