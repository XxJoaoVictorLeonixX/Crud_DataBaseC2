from model.jogadores import Jogadores
from conexion.oracle_queries import OracleQueries

class Controller_Jogadores:
    def __init__(self):
        pass
        
    def inserir_jogadores(self) -> Jogadores:       
        # Cria uma nova conexão com o banco que permite alteração
        oracle = OracleQueries(can_write=True)
        oracle.connect()

        # Solicita ao usuario o novo CPF
        cpf = input("CPF (Novo): ")

        if self.verifica_existencia_jogador(oracle, cpf):
            # Solicita ao usuario o novo nome
            id_time = input("Id time: ")
            nome = input("Nome: ")
            numero =  input("Numero: ")
            data_nascimento = input("Data de Nascimento: ")
            posicao = input("Posicao: ")
            # Insere e persiste o novo jogador
            oracle.write(f"insert into jogadores values ('{cpf}','{id_time}', '{nome}', '{numero}', '{data_nascimento}', '{posicao}')")
            # Recupera os dados do novo jogador criado transformando em um DataFrame
            df_jogadores = oracle.sqlToDataFrame(f"select cpf, id_time, nome, numero, data_nacismento, posicao from jogadores where cpf = '{cpf}'")
            # Cria um novo objeto Jogador
            novo_jogador = Jogadores(df_jogadores.cpf.values[0], df_jogadores.nome.values[0])
            # Exibe os atributos do novo jogador
            print(novo_jogador.to_string())
            # Retorna o objeto novo_jogador para utilização posterior, caso necessário
            return novo_jogador
        else:
            print(f"O CPF {cpf} já está cadastrado.")
            return None

    def atualizar_jogadores(self) -> Jogadores:
        # Cria uma nova conexão com o banco que permite alteração
        oracle = OracleQueries(can_write=True)
        oracle.connect()

        # Solicita ao usuário o código do jogador a ser alterado
        cpf = int(input("CPF do jogador que deseja alterar o nome: "))

        # Verifica se o jogador existe na base de dados
        if not self.verifica_existencia_jogador(oracle, cpf):
            # Solicita a nova descrição do jogador
            novo_id_time = input("Id time(Novo): ")
            novo_nome = input("Nome(Novo): ")
            novo_numero =  input("Numero(Novo): ")
            novo_data_nascimento = input("Data de Nascimento(Novo): ")
            novo_posicao = input("Posicao(Novo): ")
            # Atualiza o nome do jogador existente
            oracle.write(f"update jogadores set nome = '{novo_id_time}', '{novo_nome}', '{novo_numero}, '{novo_data_nascimento}', '{novo_posicao}' where cpf = {cpf}")
            # Recupera os dados do novo jogador criado transformando em um DataFrame
            df_jogador = oracle.sqlToDataFrame(f"select cpf, nome from jogadores where cpf = {cpf}")
            # Cria um novo objeto jogador
            jogador_atualizado = Jogadores(df_jogador.cpf.values[0], df_jogador.nome.values[0])
            # Exibe os atributos do novo jogador
            print(jogador_atualizado.to_string())
            # Retorna o objeto jogador_atualizado para utilização posterior, caso necessário
            return jogador_atualizado
        else:
            print(f"O CPF {cpf} não existe.")
            return None

    def excluir_jogadores(self):
        # Cria uma nova conexão com o banco que permite alteração
        oracle = OracleQueries(can_write=True)
        oracle.connect()

        # Solicita ao usuário o CPF do Jogador a ser alterado
        cpf = int(input("CPF do Jogador que irá excluir: "))        

        # Verifica se o jogador existe na base de dados
        if not self.verifica_existencia_jogador(oracle, cpf):            
            # Recupera os dados do novo cliente criado transformando em um DataFrame
            df_jogador = oracle.sqlToDataFrame(f"select cpf, nome from jogadores where cpf = {cpf}")
            # Revome o jogador da tabela
            oracle.write(f"delete from jogadores where cpf = {cpf}")            
            # Cria um novo objeto Jogador para informar que foi removido
            jogador_excluido = Jogadores(df_jogador.cpf.values[0], df_jogador.nome.values[0])
            # Exibe os atributos do jogador excluído
            print("Jogador Removido com Sucesso!")
            print(jogador_excluido.to_string())
        else:
            print(f"O CPF {cpf} não existe.")

    def verifica_existencia_jogadores(self, oracle:OracleQueries, cpf:str=None) -> bool:
        # Recupera os dados do novo jogador criado transformando em um DataFrame
        df_jogador = oracle.sqlToDataFrame(f"select cpf, nome from jogadores where cpf = {cpf}")
        return df_jogador.empty