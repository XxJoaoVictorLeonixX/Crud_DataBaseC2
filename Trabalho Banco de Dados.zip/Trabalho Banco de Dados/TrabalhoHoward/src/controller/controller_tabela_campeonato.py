from model.tabelaCampeonato import TabelaCampeonato  
from conexion.oracle_queries import OracleQueries

class Controller_Tabela_Campeonato:
    def __init__(self):
        pass

    def inserir_tabela_campeonato(self) -> TabelaCampeonato:
        ''' Ref.: https://cx-oracle.readthedocs.io/en/latest/user_guide/plsql_execution.html#anonymous-pl-sql-blocks'''
        oracle = OracleQueries(can_write=True)
        oracle.connect()

        id_time = input("Id do Time: ")
        id_campeonato = input("Id do Campeonato: ")
        vitorias = input("Vitórias: ")
        derrotas = input("Derrotas: ")
        empates = input("Empates: ")
        gol_feito = input("Gols Feitos: ")
        gol_sofrido = input("Gols Sofridos: ")

        tabela_campeonato = TabelaCampeonato(id_time, id_campeonato, vitorias, derrotas, empates, gol_feito, gol_sofrido)

        # Insira os dados na tabela_campeonato
        oracle.write(f"INSERT INTO tabela_campeonato (id_time, id_campeonato, vitorias, derrotas, empates, gol_feito, gol_sofrido) VALUES ('{id_time}', '{id_campeonato}', '{vitorias}', '{derrotas}', '{empates}', '{gol_feito}', '{gol_sofrido}')")

        return tabela_campeonato

    def atualizar_tabela_campeonato(self, id_time, id_campeonato) -> TabelaCampeonato:
        oracle = OracleQueries(can_write=True)
        oracle.connect()

        if self.verifica_existencia_tabela_campeonato(oracle, id_time, id_campeonato):
            vitorias = input("Vitórias (atualizadas): ")
            derrotas = input("Derrotas (atualizadas): ")
            empates = input("Empates (atualizados): ")
            gol_feito = input("Gols Feitos (atualizados): ")
            gol_sofrido = input("Gols Sofridos (atualizados): ")

            tabela_campeonato = TabelaCampeonato(id_time, id_campeonato, vitorias, derrotas, empates, gol_feito, gol_sofrido)

            # Atualize os dados na tabela_campeonato
            oracle.write(f"UPDATE tabela_campeonato SET vitorias = '{vitorias}', derrotas = '{derrotas}', empates = '{empates}', gol_feito = '{gol_feito}', gol_sofrido = '{gol_sofrido}' WHERE id_time = '{id_time}' AND id_campeonato = '{id_campeonato}'")

            return tabela_campeonato
        else:
            print("A tabela de campeonato não foi encontrada.")
            return None

    def excluir_tabela_campeonato(self, id_time, id_campeonato):
        oracle = OracleQueries(can_write=True)
        oracle.connect()

        if self.verifica_existencia_tabela_campeonato(oracle, id_time, id_campeonato):
            # Exclua a tabela_campeonato do banco de dados
            oracle.write(f"DELETE FROM tabela_campeonato WHERE id_time = '{id_time}' AND id_campeonato = '{id_campeonato}'")
            print("Tabela de Campeonato excluída com sucesso.")
        else:
            print("A tabela de campeonato não foi encontrada.")

    def verifica_existencia_tabela_campeonato(self, oracle, id_time, id_campeonato):
        # Verifique a existência da tabela_campeonato no banco de dados
        query = f"SELECT COUNT(*) FROM tabela_campeonato WHERE id_time = '{id_time}' AND id_campeonato = '{id_campeonato}'"
        result = oracle.sqlToDataFrame(query)
        return result.iloc[0, 0] > 0