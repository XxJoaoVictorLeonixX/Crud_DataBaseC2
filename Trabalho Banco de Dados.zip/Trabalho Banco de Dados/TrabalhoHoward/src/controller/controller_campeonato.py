from model.campeonato import Campeonato
from conexion.oracle_queries import OracleQueries

class Controller_Campeonato:
    def __init__(self):
        pass
        
    def inserir_campeonato(self) -> Campeonato:
        ''' Ref.: https://cx-oracle.readthedocs.io/en/latest/user_guide/plsql_execution.html#anonymous-pl-sql-blocks'''
        
        oracle = OracleQueries(can_write=True)
        oracle.connect()

        id_campeonato = input("Id Campeonato (novo): ")

        if self.verifica_existencia_campeonato(oracle, id_campeonato):
            nome_campeonato = input("Nome do campeonato (Novo): ")
            premiacao = input("Prêmio do campeonato: ")  # Solicita a premiação ao usuário
            campeonato = Campeonato(id_campeonato, nome_campeonato, premiacao)  # Cria o objeto Campeonato com premiação
            oracle.write(f"insert into campeonato values ('{id_campeonato}', '{nome_campeonato}')")
            df_campeonato = oracle.sqlToDataFrame(f"select id_campeonato, nome from campeonato where id_campeonato = '{id_campeonato}'")
            return campeonato
        else:
            print(f"O campeonato {id_campeonato} já está cadastrado.")
            return None

    def atualizar_campeonato(self, id_campeonato):
        oracle = OracleQueries(can_write=True)
        oracle.connect()

        if self.verifica_existencia_campeonato(oracle, id_campeonato):
            nome_campeonato = input("Nome do campeonato (atualizado): ")
            premiacao = input("Prêmio do campeonato (atualizado): ")
            campeonato = Campeonato(id_campeonato, nome_campeonato, premiacao)

            oracle.write(f"update campeonato set nome = '{nome_campeonato}', premiacao = '{premiacao}' where id_campeonato = '{id_campeonato}'")
            return campeonato
        else:
            print(f"O campeonato {id_campeonato} não foi encontrado.")
            return None

    def excluir_campeonato(self, id_campeonato):
        oracle = OracleQueries(can_write=True)
        oracle.connect()
    
        if self.verifica_existencia_campeonato(oracle, id_campeonato):
            # Exclua o campeonato do banco de dados
            oracle.write(f"delete from campeonato where id_campeonato = '{id_campeonato}'")
            print(f"Campeonato {id_campeonato} foi excluído com sucesso.")
        else:
            print(f"O campeonato {id_campeonato} não foi encontrado.")
    

    

        