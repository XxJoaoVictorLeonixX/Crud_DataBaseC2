from model.times import Times
from conexion.oracle_queries import OracleQueries

class Controller_Times:
    def __init__(self):
        pass
        
    def inserir_times(self) -> Times:
        ''' Ref.: https://cx-oracle.readthedocs.io/en/latest/user_guide/plsql_execution.html#anonymous-pl-sql-blocks'''
        
        oracle = OracleQueries(can_write=True)
        oracle.connect()

        id_time = input("Id Time (novo): ")

        if self.verifica_existencia_times(oracle, id_time):
            nome_time = input("Nome do time (Novo): ")
            oracle.write(f"insert into times values ('{id_time}', '{nome_time}'")
            df_times = oracle.sqlToDataFrame(f"select id_time, nome from times where id_time = '{id_time}'")
            novoTime = Times(df_times.id_time.values[0], df_times.nome.values[0])
            print(novoTime.to_string())
            return novoTime
        else:
            print(f"O time {id_time} já está cadastrado.")
            return None

    def atualizar_times(self) -> Times:
        oracle = OracleQueries(can_write=True)
        oracle.connect()

        id_time = int(input("Id do time que deseja atualizar: "))

        if not self.verifica_existencia_times(oracle, id_time):
            nome = input("Nome do time (Novo): ")       
            oracle.write(f"update times set nome = '{nome}' where id_time = {id_time}")
            df_time = oracle.sqlToDataFrame(f"select id_time, nome from times where id_time = {id_time}")
            time_atualizado = Times(df_time.id_time.values[0], df_time.nome.values[0])
            print(time_atualizado.to_string())
            return time_atualizado
        else:
            print(f"O Id:{id_time} do time não existe.")
            return None

    def excluir_times(self):
        oracle = OracleQueries(can_write=True)
        oracle.connect()

        id_time = int(input("Id do time que deseja Excluir: "))        

        if not self.verifica_existencia_time(oracle, id_time):            
            df_time = oracle.sqlToDataFrame(f"select id_time, nome from times where id_time = {id_time}")
            oracle.write(f"delete from times where id_time = {id_time}")            
            time_excluido = Times(df_time.id_time.values[0], df_time.nome.values[0])
            print("Time Removido com Sucesso!")
            print(time_excluido.to_string())
        else:
            print(f"O Id:{id_time} do time não existe.")

    def verifica_existencia_times(self, oracle:OracleQueries, id_time:str=None) -> bool:
        df_times = oracle.sqlToDataFrame(f"select id_time, nome from times where id_time = {id_time}")
        return df_times.empty