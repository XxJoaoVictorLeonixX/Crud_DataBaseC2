from model.jogos import Jogos
from conexion.oracle_queries import OracleQueries

class Controller_Jogos:
    def __init__(self):
        pass
        
    def inserir_jogos(self) -> Jogos:
        ''' Ref.: https://cx-oracle.readthedocs.io/en/latest/user_guide/plsql_execution.html#anonymous-pl-sql-blocks'''
        
        # Cria uma nova conexão com o banco que permite alteração
        oracle = OracleQueries(can_write=True)
        oracle.connect()

        # Solicita ao usuario o novo jogo
        id_jogo = input("Id Jogo ")

        if self.verifica_existencia_Jogos(oracle, id_jogo):
            # Solicita ao usuario o estadio usado
            estadio = input("Qual é o estadio usado? ")
            # Solicita ao usuario o time mantande
            time_mandante = input("time_mandante:  ")
            time_visitante = input("time visitante: ")
            gol_mandante = input("Gol mandante: ")
            gol_visitante = input("Gol visitante:")
            id_campeonato = input("Id Campeonato")
            # Insere e persiste o novo Jogos
            oracle.write(f"insert into jogos values ('{id_jogo}', '{estadio}', '{time_mandante}', '{time_visitante}', '{gol_mandante}', '{gol_visitante}', '{id_campeonato}')")
            # Recupera os dados do novo Jogos criado transformando em um DataFrame
            df_Jogos = oracle.sqlToDataFrame(f"select id_jogo, estadio, time_mandante, time_visitante, gol_mandante, gol_visitante, id_campeonato, from Jogos where id_jogo = '{id_jogo}'")
            # Cria um novo objeto Jogos
            novo_Jogo = Jogos(df_Jogos.id_jogo.values[0], df_Jogos.estadio.values[0], df_Jogos.time_mandante.values[0], df_Jogos.time_visitante.values[0], df_Jogos.id_campeonato.values[0])
            # Exibe os atributos do novo Jogos
            print(novo_Jogo.to_string())
            # Retorna o objeto novo_Jogos para utilização posterior, caso necessário
            return novo_Jogo
        else:
            print(f"O Jogo {id_jogo} já está cadastrado.")
            return None

    def atualizar_jogos(self) -> Jogos:
        # Cria uma nova conexão com o banco que permite alteração
        oracle = OracleQueries(can_write=True)
        oracle.connect()

        # Solicita ao usuário o código do Jogos a ser alterado
        id_jogo = int(input("Jogo que deseja atualizar: "))

        # Verifica se o Jogos existe na base de dados
        if not self.verifica_existencia_Jogos(oracle, id_jogo):
            # Solicita ao usuario a nova razão social
            estadio = input("Razão Social (Novo): ")
            # Solicita ao usuario o novo nome fantasia
            time_mandante = input("Nome Fantasia (Novo): ")   
            time_visitante = input("time visitante: ")
            gol_mandante = input("Gol mandante: ")
            gol_visitante = input("Gol visitante:")
            id_campeonato = input("Id Campeonato") 
            # Atualiza o nome do Jogos existente
            oracle.write(f"update Jogos set estadio = '{estadio}', time_mandante = '{time_mandante}' , time_visitante = '{time_visitante}', gol_mandante = '{gol_mandante}', gol_visitante = '{gol_visitante}', id_campeonato = '{id_campeonato}' where id_jogo = {id_jogo}")
            # Recupera os dados do novo Jogos criado transformando em um DataFrame
            df_Jogos = oracle.sqlToDataFrame(f"select id_jogo, estadio, time_mandante, time_visitante, gol_mandante, gol_visitante, id_campeonato from Jogos where id_jogo = {id_jogo}")
            # Cria um novo objeto Jogos
            Jogos_atualizado = Jogos(df_Jogos.id_jogo.values[0], df_Jogos.estadio.values[0], df_Jogos.time_mandante.values[0], df_Jogos.time_visitante.values[0], df_Jogos.id_campeonato.values[0])
            # Exibe os atributos do novo Jogos
            print(Jogos_atualizado.to_string())
            # Retorna o objeto Jogos_atualizado para utilização posterior, caso necessário
            return Jogos_atualizado
        else:
            print(f"O Jogo {id_jogo} não existe.")
            return None

    def excluir_jogos(self):
        # Cria uma nova conexão com o banco que permite alteração
        oracle = OracleQueries(can_write=True)
        oracle.connect()

        # Solicita ao usuário o CPF do Jogos a ser alterado
        id_jogo = int(input("Jogo que irá excluir: "))        

        # Verifica se o Jogos existe na base de dados
        if not self.verifica_existencia_Jogos(oracle, id_jogo):            
            # Recupera os dados do novo Jogos criado transformando em um DataFrame
            df_Jogos = oracle.sqlToDataFrame(f"select id_jogo, estadio, time_mandante, time_visitante, gol_mandante, gol_visitante, id_campeonato from Jogos where id_jogo = {id_jogo}")
            # Revome o Jogos da tabela
            oracle.write(f"delete from Jogos where id_jogo = {id_jogo}")            
            # Cria um novo objeto Jogos para informar que foi removido
            Jogos_excluido = Jogos(df_Jogos.id_jogo.values[0], df_Jogos.estadio.values[0], df_Jogos.time_mandante.values[0], df_Jogos.time_visitante.values[0], df_Jogos.id_campeonato.values[0])
            # Exibe os atributos do Jogos excluído
            print("Jogo Removido com Sucesso!")
            print(Jogos_excluido.to_string())
        else:
            print(f"O Jogo {id_jogo} não existe.")

    def verifica_existencia_jogos(self, oracle:OracleQueries, id_jogo:str=None) -> bool:
        # Recupera os dados do novo Jogos criado transformando em um DataFrame
        df_Jogos = oracle.sqlToDataFrame(f"select id_jogo, estadio, time_mandante, time_visitante, gol_mandante, gol_visitante, id_campeonato from Jogos where id_jogo = {id_jogo}")
        return df_Jogos.empty