from conexion.oracle_queries import OracleQueries
from utils import config

class SplashScreen:

    def __init__(self):
        # Consultas de contagem de registros - inicio
        self.qry_total_times = config.QUERY_COUNT.format(tabela="times")
        self.qry_total_jogadores = config.QUERY_COUNT.format(tabela="jogadores")
        self.qry_total_campeonato = config.QUERY_COUNT.format(tabela="campeonato")
        self.qry_total_tabela_campeonato = config.QUERY_COUNT.format(tabela="tabela_campeonato")
        self.qry_total_jogos = config.QUERY_COUNT.format(tabela="jogos")
        # Consultas de contagem de registros - fim

        # Nome(s) do(s) criador(es)
        self.created_by = "João Victor Leoni dos santos\n"
        + "Lucas Fraga de Andrade\n"
        + "Daniel José Holz\n"
        + "Gabriel dos Santos\n"
        + "Jhean Virginio Perim Pazetto\n"
        + "Guilherme Barbosa Medici Loureiro\n"
        + "Maria Eduarda Carlete"
        self.professor = "Prof. M.Sc. Howard Roatti"
        self.disciplina = "Banco de Dados"
        self.semestre = "2023/2"

    def get_total_times(self):
        # Cria uma nova conexão com o banco que permite alteração
        oracle = OracleQueries()
        oracle.connect()
        # Retorna o total de registros computado pela query
        return oracle.sqlToDataFrame(self.qry_total_times)["total_times"].values[0]

    def get_total_jogadores(self):
        # Cria uma nova conexão com o banco que permite alteração
        oracle = OracleQueries()
        oracle.connect()
        # Retorna o total de registros computado pela query
        return oracle.sqlToDataFrame(self.qry_total_jogadores)["total_jogadores"].values[0]

    def get_total_campeonato(self):
        # Cria uma nova conexão com o banco que permite alteração
        oracle = OracleQueries()
        oracle.connect()
        # Retorna o total de registros computado pela query
        return oracle.sqlToDataFrame(self.qry_total_campeonato)["total_campeonato"].values[0]

    def get_total_tabela_campeonato(self):
        # Cria uma nova conexão com o banco que permite alteração
        oracle = OracleQueries()
        oracle.connect()
        # Retorna o total de registros computado pela query
        return oracle.sqlToDataFrame(self.qry_total_tabela_campeonato)["total_tabela_campeonato"].values[0]

    def get_total_jogos(self):
        # Cria uma nova conexão com o banco que permite alteração
        oracle = OracleQueries()
        oracle.connect()
        # Retorna o total de registros computado pela query
        return oracle.sqlToDataFrame(self.qry_total_jogos)["total_jogos"].values[0]

    def get_updated_screen(self):
        return f"""
        ########################################################
        #                   SISTEMA DE VENDAS                     
        #                                                         
        #  TOTAL DE REGISTROS:                                    
        #      1 - TIMES:                   {str(self.get_total_times()).rjust(5)}
        #      2 - JOGADORES:               {str(self.get_total_jogadores()).rjust(5)}
        #      3 - CAMPEONATO:              {str(self.get_total_campeonato()).rjust(5)}
        #      4 - TABELA DO CAMPEONATO:    {str(self.get_total_tabela_campeonato()).rjust(5)}
        #      5 - JOGOS:                   {str(self.get_total_jogos()).rjust(5)}
        #
        #  CRIADO POR: {self.created_by}
        #
        #  PROFESSOR:  {self.professor}
        #
        #  DISCIPLINA: {self.disciplina}
        #              {self.semestre}
        ########################################################
        """